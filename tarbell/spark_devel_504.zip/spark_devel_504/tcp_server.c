    /*************************************************** 
    ***************************************************/  
     #include <sys/types.h>  
     #include <sys/socket.h>  
     #include <stdio.h>  
     #include <netinet/in.h>  
     #include <arpa/inet.h>  
     #define __USE_GNU
     #include <unistd.h>  
     #include <stdlib.h>  
     #include <pthread.h> 
     #include <fcntl.h>
     
     struct task_arg {
        int fd;
	    uint32_t cpu;
     };

     void *rec_data(void *fd);  
     int main(int argc,char *argv[])  
     {  
            int server_sockfd;  
            int *client_sockfd;  
            int server_len, client_len;  
            struct sockaddr_in server_address;  
            struct sockaddr_in client_address;  
            struct sockaddr_in tempaddr;  
            int i,flags,byte,ret;  
            char char_recv,char_send;  
            socklen_t templen;  
            server_sockfd = socket(AF_INET, SOCK_STREAM, 0);//�����׽���  
        
            server_address.sin_family = AF_INET;  
            server_address.sin_addr.s_addr =  htonl(INADDR_ANY);  
            server_address.sin_port = htons(9734);  
            server_len = sizeof(server_address);  
            int on=1; 
            setsockopt(server_sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));        
            int sock_buf_size=0x5c00;
            ret = setsockopt(server_sockfd,SOL_SOCKET,SO_SNDBUF,(char *)&sock_buf_size,sizeof(sock_buf_size)); 
            sock_buf_size=0x15800;
            ret = setsockopt(server_sockfd,SOL_SOCKET,SO_RCVBUF,(char *)&sock_buf_size,sizeof(sock_buf_size));

	    bind(server_sockfd, (struct sockaddr *)&server_address, server_len);//���׽���  
            templen = sizeof(struct sockaddr);  
       
            ret = listen(server_sockfd,5);
            if (ret < 0) {
                 perror("listen err");
                 return -1;
            }

            printf("server waiting for connect\n");
            int k=0; 
            struct task_arg task[100];
            while(1){  
                   pthread_t thread;//������ͬ�����߳�������ͬ�Ŀͻ���  
                   client_sockfd = (int *)malloc(sizeof(int));  
                   client_len = sizeof(client_address);  
                   *client_sockfd = accept(server_sockfd,(struct sockaddr *)&client_address, (socklen_t *)&client_len);  
                   if(-1==*client_sockfd){  
                          perror("accept");  
                          continue;  
                   } 
                   flags = fcntl(*client_sockfd,F_GETFL,0);//获取建立的sockfd的当前状态（非阻塞）
                   fcntl(*client_sockfd,F_SETFL,flags|O_NONBLOCK);//将当前sockfd设置为�
	           
                   task[k].fd=*client_sockfd;
                   task[k].cpu=10+k;
                   if(pthread_create(&thread, NULL, rec_data, (void *)&task[k])!=0)//�������߳�  
                   {  
                          perror("pthread_create");  
                          break;  
                   }  
                   k++;
            }  
            shutdown(*client_sockfd,2);  
            shutdown(server_sockfd,2);  
     }  
     /***************************************** 
     *****************************************/  
#define MAX_SIZE 0x4000
     void *rec_data(void *arg)  
     {  
            int client_sockfd;  
	        struct task_arg *args=(struct task_arg *)(arg);
            int i,byte,err;  
            char char_recv[100];//�������  
            client_sockfd=args->fd;  
	        cpu_set_t cpuset;
	        CPU_ZERO(&cpuset);
	        CPU_SET(args->cpu,&cpuset);
	        err=pthread_setaffinity_np(pthread_self(),sizeof(cpu_set_t),&cpuset);
            if (err < 0)
                error(EXIT_FAILURE, -err, "%s():", __func__);

            for(;;)  
            {  
                   if((byte=recv(client_sockfd,char_recv,100,0))==-1)  
                   {  
                          //perror("recv");  
                          //exit(EXIT_FAILURE); 
                            
                   }  
       //            if(strcmp(char_recv, "exit")==0)//���ܵ�exitʱ������ѭ��  
        //                  break;  
         //          printf("receive from client is %s/n",char_recv);//��ӡ�յ�������  
            }

            close(client_sockfd);  
            pthread_exit(NULL);  
     } 

